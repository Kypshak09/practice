username = document.querySelector('#username');
password1 = document.querySelector('#password1');
password2 = document.querySelector('#password2');
submitBtn = document.querySelector('#submit');

usernameCheck = false;
password1Check = false;
password2Check = false;
submitBtn.disabled = true;


username.addEventListener('input', () => {
  if (username.value.length > 0) {
    username.classList.remove('is-invalid');
    usernameCheck = true;
  } else {
    username.classList.add('is-invalid');
    usernameCheck = false;
  }
  validate();
})

password1.addEventListener('input', () => {
  if (password1.value.length >= 8) {
    password1.classList.remove('is-invalid');
    password1Check = true;
  } else {
    password1.classList.add('is-invalid');
    password1Check = false;
  }
  validate();
})

password2.addEventListener('input', () => {
  if (password2.value == password1.value) {
    password2.classList.remove('is-invalid');
    password2Check = true;
  } else {
    password2.classList.add('is-invalid');
    password2Check = false;
  }
  validate();
})

function validate() {
  if (usernameCheck && password1Check && password2Check) {
    submitBtn.disabled = false;
  }
}

function submitForm() {
  window.alert("You registered successfully!");
  location.reload();
}